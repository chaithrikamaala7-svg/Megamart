const express = require('express');
const PDFDocument = require('pdfkit');
const stream = require('stream');
const nodemailer = require('nodemailer');
const { validate } = require('email-validator');
const Order = require('./models/Order');
const Payment = require('./models/Payment');

const router = express.Router();

router.post('/send-pdf', async (req, res) => {
  // Debug log to check what data is received
  console.log('PDF GENERATION REQ.BODY:', JSON.stringify(req.body, null, 2));

  let { email, address, order, cart, paymentStatus, bill, orderId } = req.body;
  const sendTo = email || (address && address.email);

  if (!sendTo || !validate(sendTo)) {
    return res.status(400).json({ error: 'Invalid email address' });
  }

  try {
    // If orderId is provided and order is not, fetch order from DB
    if (orderId && !order) {
      order = await Order.findById(orderId)
        .populate('userId')
        .populate('products.productId'); // removed .lean()
      if (!order) {
        return res.status(404).json({ error: 'Order not found' });
      }
      // Debug: print the full order object
      console.log('Fetched Order:', JSON.stringify(order, null, 2));
    }

    // Fetch payment details if reference exists
    let paymentDetails = null;
    if (order && order.payment && order.payment.reference) {
      // Try to fetch by razorpay_order_id, then by payment id if not found
      paymentDetails = await Payment.findOne({ razorpay_order_id: order.payment.reference });
      if (!paymentDetails && order.payment.razorpay_payment_id) {
        paymentDetails = await Payment.findOne({ razorpay_payment_id: order.payment.razorpay_payment_id });
      }
      if (!paymentDetails) {
        console.log('No Payment found for reference:', order.payment.reference, 'or payment id:', order.payment.razorpay_payment_id);
      } else {
        console.log('Fetched Payment:', JSON.stringify(paymentDetails, null, 2));
      }
    }

    const doc = new PDFDocument();
    const passthrough = new stream.PassThrough();
    let pdfBuffers = [];

    passthrough.on('data', (chunk) => pdfBuffers.push(chunk));
    passthrough.on('end', async () => {
      const pdfData = Buffer.concat(pdfBuffers);
      let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.SMTP_EMAIL || 'Megamart',
          pass: process.env.SMTP_PASSWORD || 'kezx qtkg ayyq qajx',
        },
      });
      try {
        await transporter.sendMail({
          from: process.env.SMTP_EMAIL ||'Megamart',
          to: sendTo,
          subject: 'Your Megamart Order Bill',
          text: 'Attached is your order bill PDF.',
          attachments: [
            {
              filename: 'bill.pdf',
              content: pdfData,
            },
          ],
        });
        console.log('PDF sent to:', sendTo);
        res.json({ success: true });
      } catch (emailErr) {
        console.error('Email send error:', emailErr);
        res.status(500).json({ error: 'Failed to send email', details: emailErr.message });
      }
    });

   
    doc.pipe(passthrough);
    doc.fontSize(22).text('Megamart: order', { align: 'center' });
    doc.moveDown();

    // Order ID in title (safe access)
    const orderIdValue = order && order._id ? order._id : '-';
    doc.fontSize(12).text(`${orderIdValue} placed`, { align: 'center' });
    doc.moveDown();
    doc.fontSize(12).text('Hello,');
    doc.moveDown(0.5);
    doc.text('Your order has been placed successfully.');
    doc.moveDown();

   
    // Prefer user details from populated userId, fallback to address
    const userName = order?.userId?.name || address?.name || '-';
    const userEmail = order?.userId?.email || address?.email || '-';
    const userMobile = order?.userId?.mobile || address?.mobile || '-';
    doc.font('Helvetica-Bold').text('Customer Name: ', { continued: true }).font('Helvetica').text(userName, { continued: false });
    doc.font('Helvetica-Bold').text('Customer Email: ', { continued: true }).font('Helvetica').fillColor('blue').text(userEmail, { link: `mailto:${userEmail}`, underline: false, continued: false }).fillColor('black');
    doc.font('Helvetica-Bold').text('Customer Mobile: ', { continued: true }).font('Helvetica').text(userMobile, { continued: false });
    doc.moveDown(0.5);

   
    const orderDate = order?.date ? new Date(order.date).toLocaleString() : '-';
    const orderStatus = order?.status || '-';
    const paymentMethod = order?.payment?.method || '-';
    const paymentDetail = order?.payment?.reference || '-';
    const paymentStatusField = order?.payment?.status || paymentStatus || '-';
    const paymentReference = order?.payment?.reference || '-';
    const totalAmount = order?.totalAmount || (bill?.grandTotal || '-');

    doc.font('Helvetica-Bold').text('Order ID: ', { continued: true }).font('Helvetica').text(orderIdValue, { continued: false });
    doc.font('Helvetica-Bold').text('Date: ', { continued: true }).font('Helvetica').text(orderDate, { continued: false });
    doc.font('Helvetica-Bold').text('Order Status: ', { continued: true }).font('Helvetica').text(orderStatus, { continued: false });
    doc.font('Helvetica-Bold').text('Payment Method: ', { continued: true }).font('Helvetica').text(paymentMethod, { continued: false });
    doc.font('Helvetica-Bold').text('Payment Detail: ', { continued: true }).font('Helvetica').text(paymentDetail, { continued: false });
    doc.font('Helvetica-Bold').text('Payment Status: ', { continued: true }).font('Helvetica').text(paymentStatusField, { continued: false });
    doc.font('Helvetica-Bold').text('Payment Reference: ', { continued: true }).font('Helvetica').text(paymentReference, { continued: false });
    doc.font('Helvetica-Bold').text('Total Amount: ', { continued: true }).font('Helvetica').text(`₹${totalAmount}`, { continued: false });
    doc.moveDown();

    // Email status fields
    doc.font('Helvetica-Bold').text('Email (checkout): ', { continued: true }).font('Helvetica').text(order?.emailOnOrder || '-', { continued: false });
    doc.font('Helvetica-Bold').text('Email (status): ', { continued: true }).font('Helvetica').text(order?.emailOnStatus || '-', { continued: false });
    doc.moveDown();

    // Razorpay payment details
    if (paymentDetails) {
      doc.font('Helvetica-Bold').text('Razorpay Payment Details:');
      doc.font('Helvetica').text(`Order ID: ${paymentDetails.razorpay_order_id || '-'}`);
      doc.font('Helvetica').text(`Payment ID: ${paymentDetails.razorpay_payment_id || '-'}`);
      doc.font('Helvetica').text(`Signature: ${paymentDetails.razorpay_signature || '-'}`);
      doc.font('Helvetica').text(`Payment Date: ${paymentDetails.date ? new Date(paymentDetails.date).toLocaleString() : '-'}`);
      doc.moveDown();
    }

    // Products Table
    const items = (order && order.products) ? order.products : (cart || []);
    if (items.length > 0) {
      doc.font('Helvetica-Bold').text('Products:');
      doc.moveDown(0.5);
      // Table columns: #, Item, Qty, Price
      const tableTop = doc.y;
      const col1 = 50, col2 = 100, col3 = 350, col4 = 420;
      doc.font('Helvetica-Bold');
      doc.text('#', col1, tableTop);
      doc.text('Item', col2, tableTop);
      doc.text('Qty', col3, tableTop);
      doc.text('Price', col4, tableTop);
      doc.font('Helvetica');
      let y = tableTop + 18;
      items.forEach((item, idx) => {
        // Prefer product name from populated productId
        const productName = item.productId?.name || item.name || '-';
        const productPrice = item.price || (item.productId?.price ?? '-');
        doc.text(String(idx + 1), col1, y);
        doc.text(productName, col2, y, { width: col3 - col2 - 10 });
        doc.text(String(item.quantity || 1), col3, y);
        doc.text(`₹${productPrice}`, col4, y);
        y += 18;
      });
      // Show total amount at the end of the table for visibility
      y += 10;
      doc.font('Helvetica-Bold').text('Total Amount:', col3, y);
      doc.font('Helvetica-Bold').text(`₹${totalAmount}`, col4, y);
      doc.moveDown();
    } else {
      doc.text('No products found for this order.');
    }

    doc.moveDown();
    doc.fontSize(11).text('Sent by Megamart', { align: 'center' });
    doc.end();
  } catch (err) {
    console.error('PDF/email error:', err);
    res.status(500).json({ error: 'Failed to send PDF', details: err.message });
  }
});

module.exports = router;
